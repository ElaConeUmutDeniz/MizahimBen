
export const DEFAULT_JOKE_SOURCE_URL = 'https://raw.githubusercontent.com/ElaConeUmutDeniz/MizahimBen/main/mizahimben_officalmizahlar/mizahlist.json';
export const ALLOWED_SOURCES_URL = 'https://raw.githubusercontent.com/ElaConeUmutDeniz/MizahimBen/main/mizahimben_officalmizahlar/allowed.json';

export const FONT_OPTIONS = [
    { name: 'Montserrat', value: "'Montserrat', sans-serif" },
    { name: 'Roboto', value: "'Roboto', sans-serif" },
    { name: 'Lato', value: "'Lato', sans-serif" },
    { name: 'Open Sans', value: "'Open Sans', sans-serif" },
];
